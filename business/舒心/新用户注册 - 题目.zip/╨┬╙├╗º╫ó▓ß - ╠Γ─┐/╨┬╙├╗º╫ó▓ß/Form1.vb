﻿Public Class Form1
    Dim newPassword As String    '确认密码

    Private Sub TextBox2_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox2.TextChanged
        '当用户输入6位字符时，显示密码确认输入项
        If Len(TextBox2.Text) = 6 Then
            GroupBox1.Visible = True
        Else '否则，隐藏密码确认输入项
            GroupBox1.Visible = False
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        newPassword = newPassword & "1"     '确认密码增加一位“1”
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        newPassword = newPassword & "2"     '确认密码增加一位“2”
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        newPassword = newPassword & "3"     '确认密码增加一位“3”
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        newPassword = newPassword & "4"     '确认密码增加一位“4”
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        newPassword = newPassword & "5"
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        newPassword = newPassword & "6"
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        newPassword = newPassword & "7"
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        newPassword = newPassword & "8"
    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        newPassword = newPassword & "9"
    End Sub

    Private Sub Button0_Click(sender As System.Object, e As System.EventArgs) Handles Button0.Click
        newPassword = newPassword & "0"
    End Sub

    Private Sub ButtonClear_Click(sender As System.Object, e As System.EventArgs) Handles ButtonClear.Click
        '清空确认密码
        newPassword = ""
    End Sub

    Private Sub ButtonOK_Click(sender As System.Object, e As System.EventArgs) Handles ButtonOK.Click
        '用户第一次输入的“登录密码”与“确认密码”是否相同？
        If TextBox2.Text = newPassword Then
            '在LabelMessage上显示“恭喜你注册成功！”文字
            LabelMessage.Text = "恭喜你注册成功！"
            TextBox1.Enabled = False
            TextBox2.Enabled = False
            GroupBox1.Enabled = False
        Else
            LabelMessage.Text = "密码不一致，请重新输入。"
        End If
    End Sub
End Class
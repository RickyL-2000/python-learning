"""
Date: 2020.11.10
Author: Justin

要点说明：
1、复制字典不能直接用等号赋值，这样只是建立一个“别名”（alias）
2、“别名”可以理解成对同一个字典起了个新名字，新老名字都在用
3、要达到复制的效果，可以先建立一个空字典，再用update()函数合并字典
"""

bric = {'巴西':'Brazil', 
        '俄罗斯':'Russian Federation',
        '印度':'India', 
        '中国':'China'}

new_bric = bric # new_bric只是一个别名
new_bric['南非'] = 'South Africa' # 改变new_bric，其实就是改变bric
print(new_bric)
print(bric)

print('-'*20)

# 真正的复制字典
bric = {'巴西':'Brazil', 
        '俄罗斯':'Russian Federation',
        '印度':'India',
        '中国':'China'}
new_bric = {}  # 建立一个空字典new_bric
new_bric.update(bric)  # 将bric的内容复制到new_bric，现在new_bric和bric内容相同
new_bric['南非'] = 'South Africa' # 改变new_bric，不会影响bric
print(new_bric)
print(bric)

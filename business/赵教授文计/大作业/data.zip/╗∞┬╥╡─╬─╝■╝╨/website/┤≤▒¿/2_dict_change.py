"""
Date: 2020.11.10
Author: Justin

要点说明：
1、更新字典内容：修改、添加、删除、清空等
2、修改和添加用同样的方式，这也保证了列表的“键”不会重复
"""

UN_dict = { '中国':'China', 
            '美国':'United States',
            '俄罗斯':'Russian Federation', 
            '法国':'France', 
            '英国':'United Kingdom'}

print('字典长度：' + str(len(UN_dict)))
print('-'*20)

# 更新字典中的内容
UN_dict['美国'] = 'USA'
print(UN_dict['美国'])

print('-'*20)
# 向字典添加内容，方式和更新字典内容一样，区别在于使用了新的“键”
UN_dict['巴西'] = 'Brazil'
print(UN_dict['巴西'])

print(UN_dict)
print('字典长度：' + str(len(UN_dict)))

print('-'*20)
# 删除字典中的“键值对”。注意，删除不存在的“键”会导致程序报错
del UN_dict['英国']
print(UN_dict)
print('字典长度：' + str(len(UN_dict)))

print('-'*20)
# 清空字典
UN_dict.clear()
print(UN_dict)
print('字典长度：' + str(len(UN_dict)))

"""
Date: 2020.11.10
Author: Justin

要点说明：
合并两个字典
"""

UN_dict = { '中国':'China', 
            '美国':'United States', 
            '俄罗斯':'Russian Federation', 
            '法国':'France', 
            '英国':'United Kingdom'}
brics = {'巴西':'Brazil', 
         '俄罗斯':'RUSSIAN FEDERATION',
         '印度':'India', 
         '中国':'CHINA', 
         '南非':'South Africa'}

UN_dict.update(brics) # 合并字典
print(UN_dict)  # 注意重复键'俄罗斯'和'中国'的变化
print('-'*30)
print(brics)  # brics字典仍然存在

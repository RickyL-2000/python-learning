"""
Date: 2020.11.10
Author: Justin

要点说明：
1、字典由“键-值对”（key-value）组成
2、形式和日常的“英汉字典”形式类似
3、掌握根据“键”查找字典中对应的“值”
"""

# 声明一个字典
UN_dict = { '中国':'China', 
            '美国':'United States', 
            '俄罗斯':'Russian Federation', 
            '法国':'France', 
            '英国':'United Kingdom'}
# UNSC: United Nations Security Council

print(UN_dict)
print('------------------')
print(UN_dict['美国'])   # “查字典”的方式为：字典名[键]
print(UN_dict['俄罗斯'].upper())

print('------------------')
#print(UN_dict['德国'])  # 字典名[不存在的键] 会导致程序出错

# 不确定的情况下，应该用if语句先检查键是否在字典中（后续讲解）
# 或者使用更安全的“查字典”方式：字典名.get(键, 键不存在时返回的信息)
print(UN_dict.get('德国', '未查到'))  
print(UN_dict.get('法国', '未查到'))

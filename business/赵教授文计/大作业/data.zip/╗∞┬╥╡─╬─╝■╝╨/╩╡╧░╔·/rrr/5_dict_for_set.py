"""
Date: 2020.11.10
Author: Justin

要点说明：
1、用for循环遍历字典
2、values()函数返回字典里所有的值，可能会有重复
3、set()函数生成集合，类似列表，但没有重复值
"""

# 用字典保存各人喜欢的水果
favor = { '小张':'苹果',
          '小王':'葡萄',
          '小李':'桔子',
          '小赵':'苹果',
          '小刘':'桔子'
          }

print('---打印“值”---')
print(favor.values())
print()
print('---打印“值”的集合---')
print(set(favor.values())) # set()函数返回的是“集合”

print('='*20)
print('大家爱吃的水果包括：')
for value in set(favor.values()):  # 去除了重复值
    print(value)


"""
Date: 2020.11.10
Author: Justin

要点说明：
字典可以作为列表的元素
"""

stu_0 = {'身高':175, '体重':78, '年龄':22}
stu_1 = {'身高':188, '体重':94, '年龄':19}
stu_2 = {'身高':163, '体重':82, '年龄':25}

stu_list = [stu_0, stu_1, stu_2]

for stu in stu_list:
    print(stu)
    
print('-'*20)
print('1号学生的体重是：' +
      str(stu_list[1]['体重']) +
      '公斤。')

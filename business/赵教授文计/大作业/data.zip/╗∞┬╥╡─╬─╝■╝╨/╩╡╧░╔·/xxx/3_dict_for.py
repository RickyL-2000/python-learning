"""
Date: 2020.11.10
Author: Justin

要点说明：
1、用for循环遍历字典
2、keys()函数返回字典里所有的键
3、values()函数返回字典里所有的值
4、items()函数返回字典里所有的“键值对”
"""

# 用字典保存成绩表
achiev = {'小张':80, '小王':92, '小李':75,
          '小赵':100, '小刘':60}

print('---打印“键”---')
print(achiev.keys())
for key in achiev.keys():
    print(key)

print('---打印“值”---')
print(achiev.values())
for value in achiev.values():
    print(value)
    
print('---打印“键值对”---')
print(achiev.items()) # items()函数返回的是元组的列表
#for (key,value) in achiev.items(): 这里可以加圆括号，也可以不加
for key,value in achiev.items():
    print(key + '的成绩是' + str(value) + '分。')


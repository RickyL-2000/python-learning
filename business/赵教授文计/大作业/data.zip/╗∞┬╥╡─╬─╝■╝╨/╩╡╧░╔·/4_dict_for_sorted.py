"""
Date: 2020.11.10
Author: Justin

要点说明：
1、用for循环遍历字典，顺序是不确定的
2、可以用sorted()函数对键或值进行排序
3、注意.keys()和.values()返回的都是列表
"""

# 用字典保存成绩表
achiev = {'Zhang':80,
          'Wang':92,
          'Li':75,
          'Zhao':100,
          'Liu':60
          }

print('---按升序输出“键”---')
for key in sorted(achiev.keys()):
    print(key)

print('---按降序输出“键”---')
for key in sorted(achiev.keys(), reverse=True):
    print(key)
    
print('---按升序输出“值”---')
for value in sorted(achiev.values()):
    print(value)

print('---按降序输出“值”---')
for value in sorted(achiev.values(), reverse=True):
    print(value)

print('---“键值对”是按什么排序呢？---')
for key,value in sorted(achiev.items()):
    print(key, value)
        

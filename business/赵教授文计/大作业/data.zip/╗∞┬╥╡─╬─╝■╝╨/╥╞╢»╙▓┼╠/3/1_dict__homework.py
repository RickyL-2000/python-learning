"""
Date: 2020.11.10
Author: Justin

要点说明：
练习题：做一个成绩查询和录入系统
1、建立一个字典，包含若干“姓名:成绩”
2、用户输入学生姓名（拼音或英文），可以查询成绩
3、如果系统中没有该学生姓名，则可以为该学生录入成绩，按回车跳过录入成绩
4、可以反复查询，直到按q退出
5、退出时，打印如下信息
（1）按姓名排序，打印成绩系统中的所有条目
（2）打印学生总人数和平均成绩
"""

achiev = {'Zhang':80, 'Wang':92, 'Li':75,
          'Zhao':100, 'Liu':60}

print('---欢迎登录成绩查询和录入系统---')

while True:
    name = input('请输入姓名（按q退出）：')
    if name.lower() == 'q':
        break
    if name == '':
        continue
    
    if name in achiev.keys():
        print(name + '的成绩是：' + str(achiev[name]))
    else:
        print('没有查到' + name + '的成绩')
        score = input('请录入' + name + '的成绩（按回车跳过）:')
        if score == '':
            continue
        elif score.isdigit():
            achiev[name] = int(score)
            print('已录入：' + name + '，' + str(achiev[name]) + '分')
        else:
            print('输入不合规范，忽略……')

print('---打印全部成绩---')
print('姓名\t成绩')  # '\t'为制表符，相当于按一次TAB键
sum = 0
for name,score in sorted(achiev.items()):
    print(name + '\t' + str(score))
    sum = sum + score

num = len(achiev)
print('---总人数：' + str(num))
print('---平均分：' + str(sum//num))
    
        

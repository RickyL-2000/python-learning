"""
Date: 2020.11.10
Author: Justin

要点说明：
1、生成若干位学生的信息
2、随机生成身高、体重、年龄
3、假想场景为学校篮球队选择球员，根据身高安排位置
"""
import random as r

stu_list = []  # 空列表，用于添加学生信息

# 逐个生成学生信息，每个学生的信息是一个字典
for i in range(15):
    h = r.randrange(155,199)  # 随机产生身高
    w = r.randrange(45,95)  # 随机产生体重
    age = r.randrange(18,25)  # 随机产生年龄
    new_stu = {'身高':h, '体重':w, '年龄':age, '位置':'未分配'}
    stu_list.append(new_stu)  # 添加到列表中

## 打印列表中的信息
#for stu in stu_list:
#    print(stu)

# 根据身高粗略地分配位置
for stu in stu_list:
    if stu['身高'] >= 190:
        stu['位置'] = '中锋'
    elif stu['身高'] >= 175:
        stu['位置'] = '前锋'
    else:
        stu['位置'] = '后卫'
            
# 打印列表中的信息
for stu in stu_list:
    print(stu)

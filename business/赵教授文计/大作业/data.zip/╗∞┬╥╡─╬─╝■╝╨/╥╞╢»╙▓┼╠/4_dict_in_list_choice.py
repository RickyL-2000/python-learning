"""
Date: 2020.11.10
Author: Justin

要点说明：
1、生成若干位学生的爱好信息，如最喜欢的颜色、数字、符号等
2、掌握random.choice()函数的运用
"""

import random as r
# 空列表，用于添加学生信息
stu_list = []

# “最喜欢的XX”候选信息
color_list = ['Red','Yellow','Green','Blue','Purple']
num_list = [0,1,1,2,3,5,8,13]
char_list = 'helloworld!@#$%^&'  # 字符串可以看作特殊的列表

# 逐个生成学生信息，每个学生的信息是一个字典
for i in range(15):
    color = r.choice(color_list)  # 随机选取颜色
    num = r.choice(num_list)  # 随机选取数字
    char = r.choice(char_list)  # 随机选取字符
    new_stu = {'颜色':color, '数字':num, '字符':char}
    stu_list.append(new_stu)  # 添加到列表中

# 打印列表中的信息
for stu in stu_list:
    print(stu)

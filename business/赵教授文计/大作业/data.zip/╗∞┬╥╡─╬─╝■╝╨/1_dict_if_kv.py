"""
Date: 2020.11.10
Author: Justin

要点说明：
1、检查字典中是否有特定内容的 键
2、检查字典中是否有特定内容的 值
"""

achiev = {'小张':80, '小王':92, '小李':75,
          '小赵':100, '小刘':60}

print(achiev.keys())
print(achiev.values())

print('-'*20)

name = '小王'
if name in achiev.keys(): # 检查字典中是否有 键 等于字符串 name
    print('成绩单上有' + name + '的成绩')

score = 100
if score in achiev.values():  # 检查字典中是否有 值 等于数字100
    print('这次有人得了' + str(score) + '分')



"""
Date: 2020.11.10
Author: Justin

要点说明：
1、检查字典中是否有特定内容的 键值对
2、字典自带的items()函数返回的是元组的列表
"""

achiev = {'小张':80, '小王':92, '小李':75, '小赵':100, '小刘':60}

print(achiev.items()) # 注意items()返回的是元组的列表

print('-'*20)

name = '小王'
score = 100  # 尝试92等不同数值

## 检查字典中是否有 键值对
# 因为items()是元组的列表，这里必须要用圆括号(name,score)
if (name,score) in achiev.items(): 
    print('这次' + name + '得了' + str(score) + '分。')
else:
    print('这次' + name + '没有得到' + str(score) + '分。')


    
